# Framer Project Inventory

This file contains the current project-specific context from `framer.agent.getContext({ pagePath: '/' })`, including pages, components, CMS data, styles, fonts, icons, and IDs when available.

## Project Details

- Project ID: ph3hysB0tWbRxx9ANzXy
- Safe Project ID: ph3hysB0tWbRxx9ANzXy
- Session ID: 2
- Generated At: 2026-07-29T07:11:22.501Z

## Inventory

<project-fonts>["Inter","Manrope","JetBrains Mono"]</project-fonts>

<custom-fonts>[]</custom-fonts>

<available-components>
Each entry has "id" (stable component reference for component="..." and componentPreset.<id>) and "displayName" (human label).
Code file entries with "type": "override" are code overrides: apply them to a supported node via its codeOverride attribute. Never use override ids with component="...".
### Current Project Components
[{"id":"n_FxvJuYj","displayName":"Pille"},{"id":"nSIJJujdC","displayName":"Vermerk"},{"id":"FWFI9CGjZ","displayName":"Sektionskopf"},{"id":"WN0pIxxjN","displayName":"Seitenkopf"},{"id":"LRc9gwcGs","displayName":"Schlussstrich"},{"id":"H3M6osjEO","displayName":"Volti-Auftritt"},{"id":"G7cyejR1i","displayName":"Register"},{"id":"SuCrfJ8U5","displayName":"Ablaufschritt"},{"id":"wO4sGl0VY","displayName":"Kopfleiste"}]
### Current Project Code Files and Code Components
{}
### Current Project External Components
[]
### Additionally Available Components
[{"id":"UIrMjSS6ZX89L0CsT8k6","displayName":"Carousel","keywords":"slides swipe"},{"id":"zvkTOpMSuRzRhLzZZIwG","displayName":"Slideshow","keywords":"autoplay infinite slideshow"},{"id":"GbX8S6ghmyszcS2GLR2F","displayName":"Cookie Banner","keywords":"cookie cookies banner gdpr"},{"id":"6wAE2eMb2Tl3zrU7u4UL","displayName":"Search","keywords":"search searchbar"},{"id":"57FhkldN9P7x88MqAEaR","displayName":"Locale Selector","keywords":"language locale localization translation picker selector"},{"id":"lRDHiNWNVWmE0lqtoVHP","displayName":"Video","keywords":"player mp4 film trailer"},{"id":"NEd4VmDdsxM3StIUbddO","displayName":"YouTube","keywords":"film movie"},{"id":"NRKVbMFYrBaqL0rx532t","displayName":"MP3","keywords":"music player"},{"id":"LC4heOHJXh5Q0v49H98F","displayName":"GIF","keywords":"gif giphy"},{"id":"0sWquksFr1YDkaIgrl9Z","displayName":"Vimeo","keywords":"film movie"},{"id":"jfK7C7JmdHGaVBsvt1V7","displayName":"Dot Lottie","keywords":"animation lottie svg"},{"id":"tW1ExjbbJRt9YcZ0Gyxk","displayName":"Spotify","keywords":"music songs artist player"},{"id":"bGK4RIr3q7JjhzLaKVL7","displayName":"Apple Music","keywords":"music songs artist player"},{"id":"iH0dC3d1a99tJbx8s2oc","displayName":"SoundCloud","keywords":"music songs artist player"},{"id":"rwOL75pJfUm1chf60B4p","displayName":"Apple Podcasts","keywords":"music story radio"},{"id":"q2cL7syGc9ukRT0XBvXQ","displayName":"Simplecast","keywords":"podcast"},{"id":"CJgw13h0ok22pdnRmFv0","displayName":"Loops","keywords":"input form signup newsletter email loops loops.so"},{"id":"O4nTVQCXY50llpKf7Pq5","displayName":"Kit","keywords":"input form signup newsletter email convertkit"},{"id":"uyKL83UOiQk88ZAT4YJF","displayName":"Typeform","keywords":null},{"id":"UIhUTcd796YH7Ndybys8","displayName":"Intercom","keywords":"support"},{"id":"0dfzTKPSzK8b138I1Gsl","displayName":"Waitlist","keywords":"input form signup newsletter email getwaitlist"},{"id":"tEJqoun4MtBed1OjNwKy","displayName":"Mailchimp","keywords":"email"},{"id":"3kSszCA7P49KbVg8UUZO","displayName":"Cal.com","keywords":"cal cal.com calcom appointment scheduling schedule"},{"id":"LoWwZfPC4cHteYUUDkMp","displayName":"FormSpark","keywords":"email"},{"id":"WIJbzyan03eQVbqqCNqQ","displayName":"Calendly","keywords":"appointment scheduling schedule"},{"id":"uGQZtcsxBzvxqsgxQ0Tz","displayName":"Hubspot","keywords":"email leads sales"},{"id":"HGu8PKPDwAHu4uSgLoYR","displayName":"Instagram","keywords":"photography filters camera"},{"id":"H9CvVrwLrFYAbKP9eYKI","displayName":"Facebook","keywords":"like share"},{"id":"YLAIqVion55BUycOZr6e","displayName":"X","keywords":"tweet twitter"},{"id":"Hbc0lxqGSRzFG6uMT9yO","displayName":"Google Maps","keywords":"earth geography location globe"},{"id":"0FGMb16YHyLms7uyPaAH","displayName":"Trustpilot","keywords":"reviews"},{"id":"3aS1B1VhtklZST6WIiVW","displayName":"Tagembed","keywords":null},{"id":"1mkt2plloPEOvoe16UUK","displayName":"Lemon Squeezy","keywords":"creator earn money lemon squeezy store ecommerce"},{"id":"y2X42d2VBQUxqU0AyTRL","displayName":"Gumroad","keywords":"creator earn money store ecommerce"},{"id":"kBkaj3LmBqcSU2IkUsBC","displayName":"Download","keywords":"button file save pdf"},{"id":"Hj20QU19p80mpYsvesiZ","displayName":"Copy Clipboard","keywords":null},{"id":"o1PI5S8YtkA5bP5g4dFz","displayName":"Embed","keywords":"iframe"},{"id":"7GzNx3UWTFiuG1fPp4RN","displayName":"OpenTable","keywords":"restaurant review reservation"},{"id":"3VbLlIQuOMJh9PZyYR3D","displayName":"Product Hunt","keywords":"apps startups"},{"id":"nrfFErSfrJP9tb4xLKEk","displayName":"The Fork","keywords":"restaurant review reservation"},{"id":"wRCfuvJUFRQ0wYlJVLju","displayName":"Eventbrite","keywords":"events meetup"},{"id":"Igd9rio3gdt4sM2RsHw8","displayName":"Contra","keywords":null},{"id":"pVk4QsoHxASnVtUBp6jr","displayName":"Code Block","keywords":"code block"},{"id":"dZ9c6z10n71dmz3JQVi4","displayName":"Arc","keywords":"text"},{"id":"kbkKGd5IDiOLgcEisfwN","displayName":"Scribbles","keywords":"text"},{"id":"YA3iK3Afo27kYzYjpTSi","displayName":"Countdown","keywords":"clock time"},{"id":"HYcHVPAbe8jLEeU7c4mp","displayName":"Time & Date","keywords":"clock time"}]
</available-components>

<available-icon-sets>
### Current Site Icon Set Names
["Lucide"]
### Additionally Available Icon Set Names
["Iconic","Phosphor","Hero","Feather","Meteor","Material","Basicons","Flowbite","Nonicons","Sargam","Mage","Logos"]
</available-icon-sets>

<available-shaders>
### Current Site Shaders
[]
### Additionally Available Shaders
[{"name":"liquid-gradient","title":"Liquid Gradient","keywords":"shader gradient liquid blob organic"},{"name":"holo","title":"Holo","keywords":"shader holo"},{"name":"wave-gradient","title":"Wave Gradient","keywords":"shader gradient wave flowing ocean"},{"name":"bands","title":"Bands","keywords":"shader bands stripes"},{"name":"rings","title":"Rings","keywords":"shader rings circles concentric"},{"name":"blockify","title":"Blockify","keywords":"shader blocks blockify"},{"name":"pixels","title":"Pixels","keywords":"shader pixels"},{"name":"truchet","title":"Truchet","keywords":"shader truchet pattern tiles geometric"},{"name":"fluted-glass","title":"Fluted Glass","keywords":"shader glass fluted"},{"name":"mesh","title":"Mesh","keywords":"shader mesh gradient animated"},{"name":"particles","title":"Particles","keywords":"shader particles stars space dots hyperspace warp travel"},{"name":"chromatic-aberration","title":"Chromatic Aberration","keywords":"shader chromatic aberration"},{"name":"ripple","title":"Ripple","keywords":"shader ripple trail water distortion wave dispersion"},{"name":"logo-gradient","title":"Logo Gradient","keywords":"shader logo gradient"},{"name":"logo-glass","title":"Logo Glass","keywords":"shader logo glass metallic chrome dispersion"},{"name":"logo-spectrum","title":"Logo Spectrum","keywords":"shader logo spectrum metal"},{"name":"logo-crystal","title":"Logo Crystal","keywords":"shader logo crystal glass refraction"}]
</available-shaders>

<default-layout-template>{"id":"LIv9BuR1S","name":"Webstrom"}</default-layout-template>

<additional-context>
{"userName":"Tom Ullrich","currentDate":"July 29, 2026","timeZone":"America/New_York"}
</additional-context>

<site-map>{"augiA20Il":"/","l1J00JaO3":"/leistungen/websites","lsUbvbMVp":"/leistungen/foto-video","DDOrjZzTj":"/leistungen/wartung","V2OtGG8GW":"/energie","Eu2jP89ja":"/energie/:Energiebereiche","IoitMXiz6":"/projekte","c7OceTgT8":"/projekte/:Projekte","k_VOQri50":"/team","l5IOWUJoG":"/ueber-uns","goDo_yPB_":"/kontakt","Mg3xH3gcU":"/impressum","ThifOtYPd":"/datenschutz","KjGU8PeCr":"/agb"}</site-map>
